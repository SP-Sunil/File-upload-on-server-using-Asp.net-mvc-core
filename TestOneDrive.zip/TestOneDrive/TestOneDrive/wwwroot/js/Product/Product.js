﻿$(document).ready(function () {
    ShowProductData();
});
function ShowProductData() {

};