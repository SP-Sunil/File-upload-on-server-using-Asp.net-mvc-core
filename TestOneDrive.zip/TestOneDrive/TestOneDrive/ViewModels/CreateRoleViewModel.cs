﻿namespace TestOneDrive.ViewModels
{
    public class CreateRoleViewModel
    {
        public int Id { get; set; } 
        public string RoleName { get; set; }
    }
}
